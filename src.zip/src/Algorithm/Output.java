package Algorithm;

public class Output {
    public String out1;
    public String out2;
    public Output()
    {
    	out1="";
    	out2="";
    }
}
